package llvm2mips.llvmCommand;

public enum ComputeType {
    ADD, // +
    SUB, // -
    MUL, // *
    SDIV, // /
    SREM // %
}
