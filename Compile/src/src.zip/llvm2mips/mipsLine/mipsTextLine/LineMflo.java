package llvm2mips.mipsLine.mipsTextLine;

public class LineMflo extends MipsTextLine {
}
