package llvm2mips.mipsLine.mipsTextLine;

// 接收参数都是最终呈现的参数，对象内部不再做处理
public class MipsTextLine {
    public String toMips() {
        return null;
    }
}
