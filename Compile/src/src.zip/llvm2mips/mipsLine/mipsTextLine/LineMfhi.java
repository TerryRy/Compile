package llvm2mips.mipsLine.mipsTextLine;

public class LineMfhi extends MipsTextLine {
}
