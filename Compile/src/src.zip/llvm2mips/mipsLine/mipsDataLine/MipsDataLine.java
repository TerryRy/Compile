package llvm2mips.mipsLine.mipsDataLine;

public class MipsDataLine {
    public String toMips() {
        return null;
    }
}
