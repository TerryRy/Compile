package config;

public class Config {
    /**
     * stages of compilation
     */
    public static boolean lexer = false;
    public static boolean syner = false;
    public static boolean error = true;
    public static boolean llvm = true;
    public static boolean mips = true;
}
