package config;

public class Config {
    /**
     * stages of compilation
     */
    public static boolean lexer = false;
    public static boolean syner = false;
    public static boolean error = false;
    public static boolean llvm = true;
}
