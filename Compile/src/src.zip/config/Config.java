package config;

public class Config {
    /**
     * stages of compilation
     */
    public static boolean lexer = false;
    public static boolean syner = true;
    public static boolean error = false;
}
