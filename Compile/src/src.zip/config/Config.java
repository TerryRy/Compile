package config;

public class Config {
    /**
     * stages of compilation
     */
    public static boolean lexer = true;
    public static boolean syner = false;
    public static boolean error = false;
}
