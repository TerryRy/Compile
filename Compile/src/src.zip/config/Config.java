package config;

public class Config {
    /**
     * stages of compilation
     */
    public static boolean lexer = false;
    public static boolean syner = true;
    public static boolean error = true;
    public static boolean ir = true;
    public static boolean mips = true;
}
