package llvm2mips.mipsLine.mipsTextLine;

public class LineSne extends MipsTextLine {
}
