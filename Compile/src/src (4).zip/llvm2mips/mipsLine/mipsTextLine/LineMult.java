package llvm2mips.mipsLine.mipsTextLine;

public class LineMult extends MipsTextLine {
}
