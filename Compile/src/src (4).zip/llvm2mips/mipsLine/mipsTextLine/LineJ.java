package llvm2mips.mipsLine.mipsTextLine;

public class LineJ extends MipsTextLine {
}
