package llvm2mips.mipsLine.mipsTextLine;

public class LineSge extends MipsTextLine {
}
