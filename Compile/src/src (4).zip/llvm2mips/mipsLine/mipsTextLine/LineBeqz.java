package llvm2mips.mipsLine.mipsTextLine;

public class LineBeqz extends MipsTextLine {
}
