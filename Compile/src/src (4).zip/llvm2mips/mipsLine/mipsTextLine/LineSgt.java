package llvm2mips.mipsLine.mipsTextLine;

public class LineSgt extends MipsTextLine {
}
