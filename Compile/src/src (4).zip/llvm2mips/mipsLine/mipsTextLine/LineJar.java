package llvm2mips.mipsLine.mipsTextLine;

public class LineJar extends MipsTextLine {
}
