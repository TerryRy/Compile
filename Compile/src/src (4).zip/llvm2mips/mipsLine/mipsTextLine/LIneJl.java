package llvm2mips.mipsLine.mipsTextLine;

public class LIneJl extends MipsTextLine {
}
