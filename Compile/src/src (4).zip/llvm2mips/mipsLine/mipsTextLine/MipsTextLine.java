package llvm2mips.mipsLine.mipsTextLine;

public class MipsTextLine {
    public String toMips() {
        return null;
    }
}
