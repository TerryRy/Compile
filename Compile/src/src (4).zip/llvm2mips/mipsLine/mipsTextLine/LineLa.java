package llvm2mips.mipsLine.mipsTextLine;

public class LineLa extends MipsTextLine {
}
