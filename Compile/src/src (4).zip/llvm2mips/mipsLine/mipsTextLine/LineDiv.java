package llvm2mips.mipsLine.mipsTextLine;

public class LineDiv extends MipsTextLine {
}
