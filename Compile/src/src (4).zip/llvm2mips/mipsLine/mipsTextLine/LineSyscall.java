package llvm2mips.mipsLine.mipsTextLine;

public class LineSyscall extends MipsTextLine {
}
