package llvm2mips.mipsLine.mipsTextLine;

public class LineSeq extends MipsTextLine {
}
