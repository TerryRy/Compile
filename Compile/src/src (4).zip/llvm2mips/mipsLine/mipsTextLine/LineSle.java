package llvm2mips.mipsLine.mipsTextLine;

public class LineSle extends MipsTextLine {
}
