package llvm2mips.llvmCommand;

public class LlvmCom {
    public void analyzeCom() {

    }
}
