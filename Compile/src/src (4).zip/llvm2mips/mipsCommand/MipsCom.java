package llvm2mips.mipsCommand;

public class MipsCom {
}
