package symbol;

public class Symbol {
    String name;

    public Symbol(String name) {
        this.name = name;
    }
}
