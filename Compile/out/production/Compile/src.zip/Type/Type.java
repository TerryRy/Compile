package Type;

/*
* 树状符号表type父类，仅做封装和多态用
 */
public interface Type {
    String toStringForCall();
}
